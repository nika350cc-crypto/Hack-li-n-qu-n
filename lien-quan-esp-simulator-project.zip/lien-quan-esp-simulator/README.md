# ESP Simulator for Android

## Purpose
An offline Android demo that displays simulated enemy markers, names, health bars, and distances. It does not connect to or modify Liên Quân Mobile, inspect game memory, reveal hidden player locations, or provide an in-game advantage.

## Prerequisites
- Android Studio
- JDK 17
- Android SDK Platform 35

## Build
1. Extract this project ZIP.
2. Open the extracted `lien-quan-esp-simulator` folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the generated APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Usage
Install the generated APK on an Android device. Toggle location markers, names, health bars, and distances. Use the simulation button to randomize the demo objects.

## Offset disclaimer
No game offsets are used or included. This app has no game-process access and is not an ESP cheat for Liên Quân Mobile.
